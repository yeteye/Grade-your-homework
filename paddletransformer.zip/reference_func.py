from reference import calculate_similarity
a="我讨厌外出"
b="我喜欢出去"
similarity = calculate_similarity(a, b)
print(similarity)
